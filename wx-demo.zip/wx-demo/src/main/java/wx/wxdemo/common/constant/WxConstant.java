/**
 * Project Name: wx-demo
 * File Name: WxConstant
 * Package Name: wx.wxdemo.common
 * Date: 2020/5/11 15:15
 * Author: 方瑞冬
 */
package wx.wxdemo.common.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum WxConstant {
    GRANT_TYPE("grant_type", "authorization_code"),
    LOGIN_URL("登录 URL", "https://api.weixin.qq.com/sns/jscode2session");

    private final String name;

    private final String value;
}