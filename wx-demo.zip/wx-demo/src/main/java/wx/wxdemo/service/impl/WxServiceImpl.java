/**
 * Project Name: wx-demo
 * File Name: WxServiceImpl
 * Package Name: wx.wxdemo.service.impl
 * Date: 2020/5/11 14:51
 * Author: 方瑞冬
 */
package wx.wxdemo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wx.wxdemo.common.config.WxConfig;
import wx.wxdemo.common.constant.WxConstant;
import wx.wxdemo.common.util.HttpClientUtil;
import wx.wxdemo.common.util.WxDecodeUtil;
import wx.wxdemo.dto.WxUserInfoDTO;
import wx.wxdemo.dto.WxUserPhoneDTO;
import wx.wxdemo.service.WxService;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class WxServiceImpl implements WxService {
    @Autowired
    private WxConfig wxConfig;

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:13
     * @since: JDK 1.8
     * 
     * @description: 小程序登录
     * @param: [code]
     * @return: com.alibaba.fastjson.JSONObject
     */
    @Override
    public JSONObject login(String code) {
        Map<String, String> requestParam = new HashMap<>();
        requestParam.put("appid", wxConfig.getAppid());
        requestParam.put("secret", wxConfig.getSecret());
        requestParam.put("js_code", code);
        requestParam.put("grant_type", WxConstant.GRANT_TYPE.getValue());

        JSONObject jsonObject = JSON.parseObject(HttpClientUtil.doPost(WxConstant.LOGIN_URL.getValue(), requestParam));

        //TODO 这里可以写具体的业务代码，比如将 openid 存入用户表

        return jsonObject;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 17:05
     * @since: JDK 1.8
     * 
     * @description: 解密微信用户敏感信息
     * @param: [wxUserInfoDTO]
     * @return: com.alibaba.fastjson.JSONObject
     */
    @Override
    public JSONObject decodeWxUserInfo(WxUserInfoDTO wxUserInfoDTO) {
        return WxDecodeUtil.decode(wxUserInfoDTO.getEncrypteData(), wxUserInfoDTO.getSessionKey(), wxUserInfoDTO.getIv());
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/12 9:05
     * @since: JDK 1.8
     * 
     * @description: 解密微信用户手机号信息
     * @param: [wxUserPhoneDTO]
     * @return: com.alibaba.fastjson.JSONObject
     */
    @Override
    public JSONObject decodeWxUserPhoneInfo(WxUserPhoneDTO wxUserPhoneDTO) {
        return WxDecodeUtil.decode(wxUserPhoneDTO.getEncrypteData(), wxUserPhoneDTO.getSessionKey(), wxUserPhoneDTO.getIv());
    }
}
