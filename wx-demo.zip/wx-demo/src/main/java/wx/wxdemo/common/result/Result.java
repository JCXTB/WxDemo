/**
 * Project Name: wx-demo
 * File Name: Result
 * Package Name: wx.wxdemo.common.result
 * Date: 2020/5/11 14:54
 * Author: 方瑞冬
 */
package wx.wxdemo.common.result;

import lombok.Data;

@Data
public class Result<T> {

    private Integer code;

    private String message;

    private T data;

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:00
     * @since: JDK 1.8
     * 
     * @description: 返回构造 无参
     * @param: []
     * @return: 
     */
    public Result(){

    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:00
     * @since: JDK 1.8
     * 
     * @description: 返回构造 状态码 信息
     * @param: [code, message]
     * @return: 
     */
    public Result(Integer code, String message){
        this.code = code;
        this.message = message;
        this.data = null;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:00
     * @since: JDK 1.8
     * 
     * @description: 返回构造 状态码 信息 数据
     * @param: [code, message, data]
     * @return: 
     */
    public Result(Integer code, String message, T data){
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:09
     * @since: JDK 1.8
     *
     * @description: 成功请求返回
     * @param: [data]
     * @return: wx.wxdemo.common.result.Result<T>
     */
    public Result<T> success(T data){
        return new Result<>(200, "success", data);
    }
}
