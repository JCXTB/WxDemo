/**
 * Project Name: wx-demo
 * File Name: WxUserPhoneDTO
 * Package Name: wx.wxdemo.dto
 * Date: 2020/5/12 9:03
 * Author: 方瑞冬
 */
package wx.wxdemo.dto;

import lombok.Data;

@Data
public class WxUserPhoneDTO {
    /*密钥*/
    private String sessionKey;

    /*用户敏感信息*/
    private String encrypteData;

    /*解密算法向量*/
    private String iv;
}
