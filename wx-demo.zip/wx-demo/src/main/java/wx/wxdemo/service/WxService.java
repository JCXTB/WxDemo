/**
 * Project Name: wx-demo
 * File Name: WxService
 * Package Name: wx.wxdemo.service
 * Date: 2020/5/11 14:51
 * Author: 方瑞冬
 */
package wx.wxdemo.service;

import com.alibaba.fastjson.JSONObject;
import wx.wxdemo.dto.WxUserInfoDTO;
import wx.wxdemo.dto.WxUserPhoneDTO;

public interface WxService {
    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:12
     * @since: JDK 1.8
     * 
     * @description: 小程序登录
     * @param: [code]
     * @return: com.alibaba.fastjson.JSONObject
     */
    JSONObject login(String code);

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 17:05
     * @since: JDK 1.8
     * 
     * @description: 解密微信用户敏感信息
     * @param: [wxUserInfoDTO]
     * @return: com.alibaba.fastjson.JSONObject
     */
    JSONObject decodeWxUserInfo(WxUserInfoDTO wxUserInfoDTO);
    
    /**
     * @author: 方瑞冬
     * @date: 2020/5/12 9:05
     * @since: JDK 1.8
     * 
     * @description: 解密微信用户手机号信息
     * @param: [wxUserPhoneDTO]
     * @return: com.alibaba.fastjson.JSONObject
     */
    JSONObject decodeWxUserPhoneInfo(WxUserPhoneDTO wxUserPhoneDTO);
}
