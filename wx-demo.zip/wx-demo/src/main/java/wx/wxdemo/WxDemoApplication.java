package wx.wxdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WxDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WxDemoApplication.class, args);
	}

}
