/**
 * Project Name: wx-demo
 * File Name: WxConfig
 * Package Name: wx.wxdemo.common.config
 * Date: 2020/5/11 14:39
 * Author: 方瑞冬
 */
package wx.wxdemo.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("wx")
@Data
public class WxConfig {
    private String appid;

    private String secret;
}
