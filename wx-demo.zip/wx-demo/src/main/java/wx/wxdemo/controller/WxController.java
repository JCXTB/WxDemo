/**
 * Project Name: wx-demo
 * File Name: WxController
 * Package Name: wx.wxdemo.controller
 * Date: 2020/5/11 14:25
 * Author: 方瑞冬
 */
package wx.wxdemo.controller;

import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wx.wxdemo.common.result.Result;
import wx.wxdemo.dto.WxUserInfoDTO;
import wx.wxdemo.dto.WxUserPhoneDTO;
import wx.wxdemo.service.WxService;

@RestController
@RequestMapping("/wx")
public class WxController {
    @Autowired
    private WxService wxService;

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 15:11
     * @since: JDK 1.8
     * 
     * @description: 小程序登录，接收 code，返回 openid 和 session_key
     * @param: [code]
     * @return: wx.wxdemo.common.result.Result<com.alibaba.fastjson.JSONObject>
     */
    @PostMapping("/login")
    public Result<JSONObject> login(@RequestParam String code){
        return new Result<JSONObject>().success(wxService.login(code));
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/11 17:06
     * @since: JDK 1.8
     * 
     * @description: 获取用户敏感信息
     * @param: [wxUserInfoDTO]
     * @return: wx.wxdemo.common.result.Result<com.alibaba.fastjson.JSONObject>
     */
    @PostMapping("/getUserInfo")
    public Result<JSONObject> getUserInfo(@RequestBody WxUserInfoDTO wxUserInfoDTO){
        return new Result<JSONObject>().success(wxService.decodeWxUserInfo(wxUserInfoDTO));
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/5/12 9:04
     * @since: JDK 1.8
     * 
     * @description: 获取用户手机号信息
     * @param: [wxUserPhoneDTO]
     * @return: wx.wxdemo.common.result.Result<com.alibaba.fastjson.JSONObject>
     */
    @PostMapping("/getUserPhone")
    public Result<JSONObject> getUserPhone(@RequestBody WxUserPhoneDTO wxUserPhoneDTO){
        return new Result<JSONObject>().success(wxService.decodeWxUserPhoneInfo(wxUserPhoneDTO));
    }
}
